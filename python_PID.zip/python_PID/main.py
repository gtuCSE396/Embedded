import PID
import PIDImpl
from PID import PID


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'{name}:')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('Projeee')
    val = 20
    inc = 0
    x = 0
    pid = PID(0.1, 100, -100, 0.1, 0.01, 0.5)
    while x < 100:
        inc = pid.calculate(0, val);
        print("val =", val, "inc = ",inc)
        val += inc
        x+=1

    # double val = 20;
    # for (int i = 0; i < 100; i++) {
    # double inc = pid.calculate(0, val);
    # printf("val:% 7.3f inc:% 7.3f\n", val, inc);
    # val += inc;

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
