import PIDImpl
class PID():
  def __init__(self,dt,max,min,Kp,Kd,Ki):
    self._dt = dt
    self._max = max
    self._min = min
    self._Kp = Kp
    self._Kd = Kd
    self._Ki = Ki
    self._pre_error = 0.0
    self._integral = 0.0

  def calculate(self,setpoint,pv):
    error = setpoint - pv;
    Pout = self._Kp * error;
    self._integral += error * self._dt;
    Iout = self._Ki * self._integral;

    derivative = (error - self._pre_error) / self._dt;
    Dout = self._Kd * derivative;

    # Calculate total output
    output = Pout + Iout + Dout;
    if output > self._max:
      output = self._max
    elif output < self._min:
      output = self._min

    self._pre_error = error

    return output
